/*
Navicat MySQL Data Transfer

Source Server         : localhost
Source Server Version : 50027
Source Host           : localhost:3306
Source Database       : csii_tencent_yd

Target Server Type    : MYSQL
Target Server Version : 50027
File Encoding         : 65001

Date: 2018-08-16 00:15:24
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for tx_app_identify
-- ----------------------------
DROP TABLE IF EXISTS `tx_app_identify`;
CREATE TABLE `tx_app_identify` (
  `app_id` varchar(64) NOT NULL COMMENT '分配给上游得应用标识',
  `app_secret` varchar(255) NOT NULL COMMENT '应用密码',
  `insurance_code` varchar(64) default NULL COMMENT '保险公司标识',
  `bank_code` varchar(64) default NULL COMMENT '银行标识',
  `remark` varchar(255) default NULL COMMENT '备注',
  `create_date` datetime default NULL COMMENT '创建时间',
  PRIMARY KEY  (`app_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='app授权';
