﻿1. sql.txt 为数据库导出的sql文件(会读取sql.txt或者以.sql结尾的文件)
2. 配置存放在tibatis.properties文件中
3. 执行java -jar csii-ibatis-generator.jar即可