package com.csii.pmis.service.bean.model;

import java.io.Serializable;
import java.util.Date;
import java.math.BigDecimal;

/*
 * @description app授权
 * @author tiany
 * @version 2018-08-16 modify: tiany
 * @since 1.0
 */
public class AppIdentify implements Serializable{
	/** 序列化号 */
	private static final long serialVersionUID = 2740742097168211535L;
	/** 分配给上游得应用标识 */
	private String appId;
	/** 应用密码 */
	private String appSecret;
	/** 保险公司标识 */
	private String insuranceCode;
	/** 银行标识 */
	private String bankCode;
	/** 备注 */
	private String remark;
	/** 创建时间 */
	private Date createDate;

	public String getAppId() {
		return this.appId ;
	}

	public void setAppId(String appId) {
		this.appId = appId ;
	}

	public String getAppSecret() {
		return this.appSecret ;
	}

	public void setAppSecret(String appSecret) {
		this.appSecret = appSecret ;
	}

	public String getInsuranceCode() {
		return this.insuranceCode ;
	}

	public void setInsuranceCode(String insuranceCode) {
		this.insuranceCode = insuranceCode ;
	}

	public String getBankCode() {
		return this.bankCode ;
	}

	public void setBankCode(String bankCode) {
		this.bankCode = bankCode ;
	}

	public String getRemark() {
		return this.remark ;
	}

	public void setRemark(String remark) {
		this.remark = remark ;
	}

	public Date getCreateDate() {
		return this.createDate ;
	}

	public void setCreateDate(Date createDate) {
		this.createDate = createDate ;
	}

	@Override
	public String toString() {
		final StringBuffer sb = new StringBuffer("AppIdentify{");
		sb.append("appId='").append(appId).append('\'');
		sb.append("appSecret='").append(appSecret).append('\'');
		sb.append("insuranceCode='").append(insuranceCode).append('\'');
		sb.append("bankCode='").append(bankCode).append('\'');
		sb.append("remark='").append(remark).append('\'');
		sb.append("createDate='").append(createDate);
		sb.append('}');	
		return sb.toString();
	}
}
