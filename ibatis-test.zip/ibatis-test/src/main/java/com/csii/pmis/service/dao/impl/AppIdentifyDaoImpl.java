package com.csii.pmis.service.dao.impl;

import java.util.List;
import java.util.Map;

import java.util.HashMap;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.ibatis.SqlMapClientOperations;
import org.springframework.stereotype.Repository;

import com.csii.pmis.service.dao.AppIdentifyDao;
import com.csii.pmis.service.bean.model.AppIdentify;

/*
 * @description app授权DaoImpl
 * @author tiany
 * @version 2018-08-16 modify: tiany
 * @since 1.0
 */
@Repository
public class AppIdentifyDaoImpl implements AppIdentifyDao {
	@Autowired
	private SqlMapClientOperations sqlMap;

	@Override
	public Object insert(AppIdentify appIdentify){
		return sqlMap.insert("AppIdentify.insert", appIdentify);
	}

	@Override
	public Object insertList(List<AppIdentify> appIdentifyList){
		return sqlMap.insert("AppIdentify.insertList", appIdentifyList);
	}

	@Override
	public AppIdentify selectByPrimaryKey(String appId){
		return (AppIdentify)sqlMap.queryForObject("AppIdentify.selectByPrimaryKey",appId);
	}

	@Override
	public List<AppIdentify> selectForList(Map<String,? extends Object> params){
		return sqlMap.queryForList("AppIdentify.selectForList",params);
	}

	@Override
	public int selectCountByParams(Map<String,? extends Object> params){
		return (Integer)sqlMap.queryForObject("AppIdentify.selectCountByParams",params);
	}

	@Override
	public List<Map<String,Object>> selectForMapList(Map<String,? extends Object> params){
		return sqlMap.queryForList("AppIdentify.selectForMapList",params);
	}

	@Override
	public AppIdentify selectForObject(AppIdentify appIdentify){
		return (AppIdentify)sqlMap.queryForObject("AppIdentify.selectForObject",appIdentify);
	}

	@Override
	public Map<String,Object> selectForMap(Map<String,? extends Object> params){
		return (Map<String,Object>)sqlMap.queryForObject("AppIdentify.selectForMap",params);
	}

	@Override
	public int updateByPrimaryKey(AppIdentify appIdentify){
		return sqlMap.update("AppIdentify.updateByPrimaryKey",appIdentify);
	}

	@Override
	public int updateList(List<String> appIdList,AppIdentify appIdentify){
		Map<String, Object> params = new HashMap<String,Object>();
		params.put("appIdList", appIdList);
		params.put("appIdentify", appIdentify);
		return sqlMap.update("AppIdentify.updateList",params);
	}

	@Override
	public int updateByParams(Map<String,? extends Object> params){
		return sqlMap.update("AppIdentify.updateByParams",params);
	}

	@Override
	public int deleteByPrimaryKey(String appId){
		return sqlMap.delete("AppIdentify.deleteByPrimaryKey",appId);
	}

	@Override
	public int deleteList(List<String> appIdList){
		return sqlMap.delete("AppIdentify.deleteList",appIdList);
	}

	@Override
	public int deleteByParams(Map<String,? extends Object> params){
		return sqlMap.delete("AppIdentify.deleteByParams",params);
	}

}
