package com.csii.pmis.service.dao;

import java.util.List;
import java.util.Map;

import com.csii.pmis.service.bean.model.AppIdentify;

/*
 * @description app授权Dao
 * @author tiany
 * @version 2018-08-16 modify: tiany
 * @since 1.0
 */
public interface AppIdentifyDao {
	/**
	 * 插入一条新的纪录
	 */
	Object insert(AppIdentify appIdentify);

	/**
	 * 批量新增
	 */
	Object insertList(List<AppIdentify> appIdentifyList);

	/**
	 * 根据主键查询AppIdentify
	 */
	AppIdentify selectByPrimaryKey(String appId);

	/**
	 * 根据params查询AppIdentify的List集合，params为null表示查询所有
	 */
	List<AppIdentify> selectForList(Map<String,? extends Object> params);

	/**
	 * 根据params查询AppIdentify记录的条数，params为null表示查询所有
	 */
	int selectCountByParams(Map<String,? extends Object> params);

	/**
	 * 根据params查询Map类型的List集合，params为null表示查询所有
	 */
	List<Map<String,Object>> selectForMapList(Map<String,? extends Object> params);

	/**
	 * 根据对象字段查询AppIdentify对象
	 */
	AppIdentify selectForObject(AppIdentify appIdentify);

	/**
	 * 根据params查询，返回Map类型
	 */
	Map<String,Object> selectForMap(Map<String,? extends Object> params);

	/**
	 * 根据主键更新AppIdentify
	 */
	int updateByPrimaryKey(AppIdentify appIdentify);

	/**
	 * 根据主键列表更新AppIdentify
	 */
	int updateList(List<String> appIdList,AppIdentify appIdentify);

	/**
	 * 根据params更新AppIdentify
	 */
	int updateByParams(Map<String,? extends Object> params);

	/**
	 * 根据主键删除AppIdentify
	 */
	int deleteByPrimaryKey(String appId);

	/**
	 * 根据主键列表批量删除AppIdentify
	 */
	int deleteList(List<String> appIdList);

	/**
	 * 根据params删除AppIdentify
	 */
	int deleteByParams(Map<String,? extends Object> params);

}
